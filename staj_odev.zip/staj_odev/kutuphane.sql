-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 24 Ara 2021, 19:26:33
-- Sunucu sürümü: 10.4.21-MariaDB
-- PHP Sürümü: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `kutuphane`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kitap`
--

CREATE TABLE `kitap` (
  `kitap_id` int(11) NOT NULL,
  `kitap_seri` varchar(20) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kitap_adi` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kitap_turu` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `yazar_adi` varchar(60) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kitap_konusu` varchar(255) COLLATE utf8mb4_turkish_ci NOT NULL,
  `onay` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `kitap`
--

INSERT INTO `kitap` (`kitap_id`, `kitap_seri`, `kitap_adi`, `kitap_turu`, `yazar_adi`, `kitap_konusu`, `onay`) VALUES
(2, '123124', 'Sefiller', 'Uyarlamalar', 'Victor Hugo', 'sefil', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanici`
--

CREATE TABLE `kullanici` (
  `kul_id` int(11) NOT NULL,
  `k_adi` varchar(30) COLLATE utf8mb4_turkish_ci NOT NULL,
  `k_sifre` varchar(30) COLLATE utf8mb4_turkish_ci NOT NULL,
  `onay` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `kullanici`
--

INSERT INTO `kullanici` (`kul_id`, `k_adi`, `k_sifre`, `onay`) VALUES
(1, 'admin', 'admin', 1),
(2, '', '', 0),
(3, 'esma', 'esma', 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `okunacak`
--

CREATE TABLE `okunacak` (
  `kitap_id` int(11) NOT NULL,
  `kitap_seri` varchar(25) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kitap_adi` varchar(25) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kitap_turu` varchar(25) COLLATE utf8mb4_turkish_ci NOT NULL,
  `yazar_adi` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kitap_konusu` varchar(255) COLLATE utf8mb4_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `okunacak`
--

INSERT INTO `okunacak` (`kitap_id`, `kitap_seri`, `kitap_adi`, `kitap_turu`, `yazar_adi`, `kitap_konusu`) VALUES
(1, '123123', 'asdad', 'asdasd', 'asdas', 'sadasd'),
(3, '123125', 'Uyumsuz', 'Bilimkurgu', 'Bilinmiyor', 'aksiyon');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `okunan`
--

CREATE TABLE `okunan` (
  `kitap_id` int(11) NOT NULL,
  `kitap_seri` varchar(25) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kitap_adi` varchar(25) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kitap_turu` varchar(25) COLLATE utf8mb4_turkish_ci NOT NULL,
  `yazar_adi` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kitap_konusu` varchar(255) COLLATE utf8mb4_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `okunan`
--

INSERT INTO `okunan` (`kitap_id`, `kitap_seri`, `kitap_adi`, `kitap_turu`, `yazar_adi`, `kitap_konusu`) VALUES
(1, '123123', 'asdad', 'asdasd', 'asdas', 'sadasd');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `uyeler`
--

CREATE TABLE `uyeler` (
  `uye_id` int(11) NOT NULL,
  `uye_adi` varchar(30) COLLATE utf8mb4_turkish_ci NOT NULL,
  `uye_soyadi` varchar(30) COLLATE utf8mb4_turkish_ci NOT NULL,
  `uye_mail` varchar(30) COLLATE utf8mb4_turkish_ci NOT NULL,
  `uye_tel` varchar(30) COLLATE utf8mb4_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `uyeler`
--

INSERT INTO `uyeler` (`uye_id`, `uye_adi`, `uye_soyadi`, `uye_mail`, `uye_tel`) VALUES
(1, 'Mehmet', 'Buyuk', 'mhmt.sbuyuk@gmail.com', '5350173198'),
(2, 'Mesut', 'Hocamm', 'mesut@gmaill.com', '5353239291'),
(3, 'Mehmet Şirin', 'Büyük', '200130050@firat.edu.tr', '5350173198'),
(4, '', '', '', ''),
(5, 'Esma', 'Nur', 'esma@gmail.com', '5424544323');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `kitap`
--
ALTER TABLE `kitap`
  ADD PRIMARY KEY (`kitap_id`);

--
-- Tablo için indeksler `kullanici`
--
ALTER TABLE `kullanici`
  ADD PRIMARY KEY (`kul_id`);

--
-- Tablo için indeksler `okunacak`
--
ALTER TABLE `okunacak`
  ADD PRIMARY KEY (`kitap_id`);

--
-- Tablo için indeksler `okunan`
--
ALTER TABLE `okunan`
  ADD PRIMARY KEY (`kitap_id`);

--
-- Tablo için indeksler `uyeler`
--
ALTER TABLE `uyeler`
  ADD PRIMARY KEY (`uye_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `kitap`
--
ALTER TABLE `kitap`
  MODIFY `kitap_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tablo için AUTO_INCREMENT değeri `kullanici`
--
ALTER TABLE `kullanici`
  MODIFY `kul_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Tablo için AUTO_INCREMENT değeri `okunacak`
--
ALTER TABLE `okunacak`
  MODIFY `kitap_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `okunan`
--
ALTER TABLE `okunan`
  MODIFY `kitap_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Tablo için AUTO_INCREMENT değeri `uyeler`
--
ALTER TABLE `uyeler`
  MODIFY `uye_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
