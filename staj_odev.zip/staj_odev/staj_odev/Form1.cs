﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace staj_odev
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();
       
        public Form1()
        {

            InitializeComponent();
            con = new MySqlConnection("Server=localhost;Database=kutuphane;user=root;Pwd=;SslMode=none");
            //Server=myServerAddress;Database=myDataBase;Uid=myUsername;Pwd=myPassword;
            int sayi1 = rnd.Next(100000, 999999);
            label3.Text = sayi1.ToString();

        }
        MySqlConnection con;
        MySqlCommand cmd;
        MySqlDataReader dr;

        private void btn_giris_Click(object sender, EventArgs e)
        {
            con.Close();

            con.Open();
            string user = textBox1.Text;
            string pass = textBox2.Text;
            cmd = new MySqlCommand();

            cmd.Connection = con;
            cmd.CommandText = "SELECT * FROM kullanici where k_adi='" + textBox1.Text + "' AND k_sifre='" + textBox2.Text + "'";
            dr = cmd.ExecuteReader();
            if (dr.Read() && label3.Text == textBox3.Text)
            {
                if (dr["k_adi"].ToString() == textBox1.Text && dr["k_sifre"].ToString() == textBox2.Text)
                    if (dr["onay"].ToString() == "0")
                    {
                        K_Giris kullanici = new K_Giris();
                        kullanici.Show();
                        this.Hide();
                    }
                    else if (dr["onay"].ToString() == "1")
                    {
                        A_Giris admin = new A_Giris();
                        admin.Show();
                        this.Hide();
                    }
                con.Close();
            }
            else if (textBox1.Text==""&& textBox2.Text == "" && textBox3.Text == "" && textBox4.Text == "" && textBox5.Text == "" && textBox6.Text == "" && textBox7.Text == "" && textBox8.Text == "" && textBox9.Text == "" && textBox10.Text == "" )
            {
                MessageBox.Show("Lütfen Boş Bırakmayınız..!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();

            }
            else
            {
                MessageBox.Show("Bilgiler Yanlış Lütfen Tekrar Deneyiniz..!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
            textBox9.PasswordChar = '*';
            textBox10.PasswordChar = '*';

        }

        private void btn_kayit_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                // ekleme komutunu tanımladım ve insert sorgusunu yazdım.
                MySqlCommand ekle = new MySqlCommand("insert into uyeler (uye_adi,uye_soyadi,uye_mail,uye_tel) values ('" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "')", con);
                MySqlCommand kekle = new MySqlCommand("insert into kullanici (k_adi,k_sifre) values ('" + textBox8.Text + "','" + textBox9.Text + "')", con);

                // sorguyu çalıştırıyorum.
                object sonuc,sonuc2 = null;
                sonuc = ekle.ExecuteNonQuery(); 
                sonuc2 = kekle.ExecuteNonQuery();// sorgu çalıştı ve dönen değer objec türünden değişkene geçti eğer değişken boş değilse eklendi boşşsa eklenmedi.
                if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && textBox4.Text == "" && textBox5.Text == "" && textBox6.Text == "" && textBox7.Text == "" && textBox8.Text == "" && textBox9.Text == "" && textBox10.Text == "")
                {
                    MessageBox.Show("Lütfen Boş Bırakmayınız..!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();

                }
                else  if (sonuc != null&& sonuc2 != null)
                {
                    MessageBox.Show("Sisteme başarıyla eklendi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                }
                 
                else
                {
                    MessageBox.Show("Bilgiler Yanlış Lütfen Tekrar Deneyiniz..!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();

                }

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();

                textBox5.Clear();
                textBox6.Clear();
                textBox4.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();

            }
            catch (Exception HataYakala)
            {
                MessageBox.Show("Hata: " + HataYakala.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_iptal_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void btn_cikis_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void btn_yenile_Click(object sender, EventArgs e)
        {
            int sayi1 = rnd.Next(100000, 999999);
            label3.Text = sayi1.ToString();
        }
    }
}
