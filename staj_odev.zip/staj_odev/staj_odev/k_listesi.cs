﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace staj_odev
{
    public partial class k_listesi : Form
    {
        public k_listesi()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            K_Giris kgiris = new K_Giris();
            kgiris.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        MySqlConnection con = new MySqlConnection("Server=localhost;Database=kutuphane;user=root;Pwd=;SslMode=none");
        MySqlDataAdapter da;
        MySqlCommand com = new MySqlCommand();
        DataTable table = new DataTable();
        DataTable dt = new DataTable();
        MySqlDataReader dr;

        public void musterim()//Müşterileri Listeleme fonksiyonu
        {

           
            table.Clear(); // tablomuzu bi temizliyoruz
            MySqlDataAdapter adapter = new MySqlDataAdapter("select kitap_seri, kitap_adi, kitap_turu, yazar_adi, kitap_konusu from kitap ", con);
            adapter.Fill(table);//tablomuza dataadapter ile musterileri dolduruyoruz.//bag.baglan dedik bunun olayı şu
            //bag die bir nesne oluşturduk sqlbaglantisi classımızdan bunun içindeki baglan fonksiyonumuzu çekiyoruz.Biliyorsunuz bağlantı yolumuz burda
            dataGridView1.DataSource = table;//gridwiewe de doldurdumuz tabloya aktardık


            dataGridView1.RowHeadersVisible = false;//satır başlını kaybettik sevmiyorum kaba duruyor

            dataGridView1.Columns[0].Visible = false;//bazı gereksiz kısımları görünmez yaptık görüntü güzelleştirmek açısından "id şifre gibi."
            dataGridView1.MultiSelect = false;//birden fazla satır seçielemez
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect; // seçdiğimiz datagrid satırı tamamen satırca seçilmiş görülür
        }
        private void k_listesi_Load(object sender, EventArgs e)
        {
            con.Open();
            string komut = "select kitap_seri,kitap_adi,kitap_turu,yazar_adi,kitap_konusu from kitap ";
            da = new MySqlDataAdapter(komut,con);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();


            com.Connection = con;

            try
            {

                // ekleme komutunu tanımladım ve insert sorgusunu yazdım.
                MySql.Data.MySqlClient.MySqlCommand ekle = new MySqlCommand("insert into okunan (kitap_seri,kitap_adi,kitap_turu,yazar_adi,kitap_konusu) select kitap_seri,kitap_adi,kitap_turu,yazar_adi,kitap_konusu FROM kitap ", con);

                // sorguyu çalıştırıyorum.
                object sonuc = null;
                sonuc = ekle.ExecuteNonQuery();
                if (sonuc != null)
                {

                    MessageBox.Show("Sisteme başarıyla eklendi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();

                }
                else
                {
                    MessageBox.Show("Sisteme eklenemedi.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    con.Close();
                }
                // bağlantıyı kapatalım



            }
            catch (Exception HataYakala)
            {
                MessageBox.Show("Hata: " + HataYakala.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            dataGridView1.Update();
            dataGridView1.Refresh();
            musterim();

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            dataGridView1.CurrentRow.Cells["kitap_seri"].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();


            com.Connection = con;

            try
            {

                // ekleme komutunu tanımladım ve insert sorgusunu yazdım.
                MySql.Data.MySqlClient.MySqlCommand ekle = new MySqlCommand("insert into okunacak (kitap_seri,kitap_adi,kitap_turu,yazar_adi,kitap_konusu) select kitap_seri,kitap_adi,kitap_turu,yazar_adi,kitap_konusu FROM kitap ", con);

                // sorguyu çalıştırıyorum.
                object sonuc = null;
                sonuc = ekle.ExecuteNonQuery();
                if (sonuc != null)
                {

                    MessageBox.Show("Sisteme başarıyla eklendi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();

                }
                else
                {
                    MessageBox.Show("Sisteme eklenemedi.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    con.Close();
                }
                // bağlantıyı kapatalım



            }
            catch (Exception HataYakala)
            {
                MessageBox.Show("Hata: " + HataYakala.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            dataGridView1.Update();
            dataGridView1.Refresh();
            musterim();
        }
    }
}
