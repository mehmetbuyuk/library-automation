﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace staj_odev
{
    public partial class Kitaplari_yonet : Form
    {
        public Kitaplari_yonet()
        {
            InitializeComponent();
        }

        MySqlConnection con = new MySqlConnection("Server=localhost;Database=kutuphane;user=root;Pwd=;SslMode=none");
        MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand();
        DataTable table = new DataTable();
        DataTable dt = new DataTable();
        MySqlDataReader dr;
        public void musterim()//Müşterileri Listeleme fonksiyonu
        {

            txt_seri.Text = "";//textboxları doluysalar bi temizliyoruz
            txt_konu.Text = "";
            txt_turu.Text = "";
            txt_kadi.Text = "";
            txt_yazar.Text = "";
            txt_onay.Text = "";
            table.Clear(); // tablomuzu bi temizliyoruz
            MySqlDataAdapter adapter = new MySqlDataAdapter("select * FROM kitap", con);
            adapter.Fill(table);//tablomuza dataadapter ile musterileri dolduruyoruz.//bag.baglan dedik bunun olayı şu
            //bag die bir nesne oluşturduk sqlbaglantisi classımızdan bunun içindeki baglan fonksiyonumuzu çekiyoruz.Biliyorsunuz bağlantı yolumuz burda
            dataGridView1.DataSource = table;//gridwiewe de doldurdumuz tabloya aktardık
         

            dataGridView1.RowHeadersVisible = false;//satır başlını kaybettik sevmiyorum kaba duruyor
           
            dataGridView1.Columns[0].Visible = false;//bazı gereksiz kısımları görünmez yaptık görüntü güzelleştirmek açısından "id şifre gibi."
            dataGridView1.MultiSelect = false;//birden fazla satır seçielemez
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect; // seçdiğimiz datagrid satırı tamamen satırca seçilmiş görülür
        }
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "UPDATE kitap SET kitap_seri='" + txt_seri.Text + "' , kitap_adi='" + txt_kadi.Text + "',kitap_turu='" + txt_turu.Text + "',yazar_adi='" + txt_yazar.Text + "',kitap_konusu='" + txt_konu.Text + "' where kitap_id='" + dataGridView1.CurrentRow.Cells["kitap_id"].Value.ToString() + "'";

            cmd.ExecuteNonQuery();
            cmd.Dispose();
            MessageBox.Show("Güncelleme İşlemi Başarılı");
            musterim();
        }

        private void Kitaplari_yonet_Load(object sender, EventArgs e)
        {
            musterim();
            dataGridView1.DataSource = null;

            MySqlDataAdapter adapter = new MySqlDataAdapter("select * FROM kitap  ", con);
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.RowHeadersVisible = false;

            con.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "DELETE FROM kitap WHERE kitap_id = '" + dataGridView1.CurrentRow.Cells["kitap_id"].Value.ToString() + "'";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Silme İşlemi Başarılı");
            musterim();
        }

        private void button3_Click(object sender, EventArgs e)
        {
         
            con.Close();
            con.Open();
            

            cmd.Connection = con;

            try
            {

                // ekleme komutunu tanımladım ve insert sorgusunu yazdım.
                MySql.Data.MySqlClient.MySqlCommand ekle = new MySqlCommand("insert into kitap (kitap_seri,kitap_adi,kitap_turu,yazar_adi,kitap_konusu,onay) values ('" + txt_seri.Text + "','" + txt_kadi.Text + "','" + txt_turu.Text + "','" + txt_yazar.Text + "','" + txt_konu.Text + "','" + txt_onay.Text + "')", con);

                // sorguyu çalıştırıyorum.
                object sonuc= null;
                sonuc = ekle.ExecuteNonQuery();
                if (sonuc != null)
                {
                    MessageBox.Show("Sisteme başarıyla eklendi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();

                }
                else
                {
                    MessageBox.Show("Sisteme eklenemedi.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    con.Close();
                }
                // bağlantıyı kapatalım

             

            }
            catch (Exception HataYakala)
            {
                MessageBox.Show("Hata: " + HataYakala.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            txt_seri.Text = "";//textboxları doluysalar bi temizliyoruz
            txt_konu.Text = "";
            txt_turu.Text = "";
            txt_kadi.Text = "";
            txt_yazar.Text = "";
            txt_onay.Text = "";
            dataGridView1.Update();
            dataGridView1.Refresh();
            musterim();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_seri.Text = dataGridView1.CurrentRow.Cells["kitap_seri"].Value.ToString();
            txt_kadi.Text = dataGridView1.CurrentRow.Cells["kitap_adi"].Value.ToString();
            txt_turu.Text = dataGridView1.CurrentRow.Cells["kitap_turu"].Value.ToString();
            txt_yazar.Text = dataGridView1.CurrentRow.Cells["yazar_adi"].Value.ToString();
            txt_konu.Text = dataGridView1.CurrentRow.Cells["kitap_konusu"].Value.ToString();
            txt_onay.Text = dataGridView1.CurrentRow.Cells["onay"].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "UPDATE kitap SET onay='" + txt_onay.Text + "'  where kitap_id='" + dataGridView1.CurrentRow.Cells["kitap_id"].Value.ToString() + "'";
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            MessageBox.Show("Kitap Başarıyla Onaylandı.");
            musterim();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "UPDATE kitap SET onay='" + txt_onay.Text + "'  where kitap_id='" + dataGridView1.CurrentRow.Cells["kitap_id"].Value.ToString() + "'";
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            MessageBox.Show("Kitap Başarıyla Reddeildi.");
            musterim();
        }
    }
}
