﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace staj_odev
{
    public partial class Uye_listesi : Form
    {
        public Uye_listesi()
        {
            InitializeComponent();

            //Server=myServerAddress;Database=myDataBase;Uid=myUsername;Pwd=myPassword;
        

        }

        MySqlConnection con = new MySqlConnection("Server=localhost;Database=kutuphane;user=root;Pwd=;SslMode=none");
        MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand();
        DataTable table = new DataTable();
        DataTable dt = new DataTable();
        public void musterim()//Müşterileri Listeleme fonksiyonu
        {
            txt_adi.Text = "";//textboxları doluysalar bi temizliyoruz
            txt_kadi.Text = "";
            txt_mail.Text = "";
            txt_sifre.Text = "";
            txt_soyadi.Text = "";
            txt_telefon.Text = "";
            table.Clear(); // tablomuzu bi temizliyoruz
            MySqlDataAdapter adapter = new MySqlDataAdapter("select * FROM kullanici  INNER JOIN uyeler", con);
            adapter.Fill(table);//tablomuza dataadapter ile musterileri dolduruyoruz.//bag.baglan dedik bunun olayı şu
            //bag die bir nesne oluşturduk sqlbaglantisi classımızdan bunun içindeki baglan fonksiyonumuzu çekiyoruz.Biliyorsunuz bağlantı yolumuz burda
            dataGridView1.DataSource = table;//gridwiewe de doldurdumuz tabloya aktardık
            dataGridView2.DataSource = table;

            dataGridView1.RowHeadersVisible = false;//satır başlını kaybettik sevmiyorum kaba duruyor
            dataGridView2.RowHeadersVisible = false;

            dataGridView1.Columns[0].Visible = false;//bazı gereksiz kısımları görünmez yaptık görüntü güzelleştirmek açısından "id şifre gibi."
            dataGridView1.MultiSelect = false;//birden fazla satır seçielemez
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect; // seçdiğimiz datagrid satırı tamamen satırca seçilmiş görülür

            dataGridView2.Columns[0].Visible = false;
            dataGridView2.MultiSelect = false;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
   
            txt_kadi.Text = dataGridView2.CurrentRow.Cells["k_adi"].Value.ToString();
            txt_sifre.Text = dataGridView2.CurrentRow.Cells["k_sifre"].Value.ToString();
            txt_onay.Text = dataGridView2.CurrentRow.Cells["onay"].Value.ToString();

        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_adi.Text = dataGridView1.CurrentRow.Cells["uye_adi"].Value.ToString();
            txt_soyadi.Text = dataGridView1.CurrentRow.Cells["uye_soyadi"].Value.ToString();
            txt_mail.Text = dataGridView1.CurrentRow.Cells["uye_mail"].Value.ToString();
            txt_telefon.Text = dataGridView1.CurrentRow.Cells["uye_tel"].Value.ToString();
        }

        private void Uye_listesi_Load(object sender, EventArgs e)
        {
            musterim();
            dataGridView1.DataSource = null;
            dataGridView2.DataSource = null;
            MySqlDataAdapter adapter = new MySqlDataAdapter("select * FROM kullanici  INNER JOIN uyeler", con);
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.RowHeadersVisible = false;
            dataGridView2.DataSource = dt;
            dataGridView2.RowHeadersVisible = false;
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            

            cmd.Connection = con;
           
            try
            {

                // ekleme komutunu tanımladım ve insert sorgusunu yazdım.
                MySql.Data.MySqlClient.MySqlCommand ekle = new MySqlCommand("insert into uyeler (uye_adi,uye_soyadi,uye_mail,uye_tel) values ('" + txt_adi.Text + "','" + txt_soyadi.Text + "','" + txt_mail.Text + "','" + txt_telefon.Text + "')", con);
                MySql.Data.MySqlClient.MySqlCommand kekle = new MySqlCommand("insert into kullanici (k_adi,k_sifre) values ('" + txt_kadi.Text + "','" + txt_sifre.Text + "')", con);

                // sorguyu çalıştırıyorum.
                object sonuc, sonuc2 = null;
                sonuc = ekle.ExecuteNonQuery();
                sonuc2 = kekle.ExecuteNonQuery();// sorgu çalıştı ve dönen değer objec türünden değişkene geçti eğer değişken boş değilse eklendi boşşsa eklenmedi.
                if (sonuc != null && sonuc2 != null) { 
                    MessageBox.Show("Sisteme başarıyla eklendi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                    
                }
                else
                    MessageBox.Show("Sisteme eklenemedi.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                // bağlantıyı kapatalım

                txt_adi.Clear();
                txt_kadi.Clear();
                txt_mail.Clear();

                txt_sifre.Clear();
                txt_soyadi.Clear();
                txt_telefon.Clear();

                dataGridView1.Update();
                dataGridView1.Refresh();

            }
            catch (Exception HataYakala)
            {
                MessageBox.Show("Hata: " + HataYakala.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

       
       

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "DELETE FROM uyeler WHERE uye_id = '" + dataGridView1.CurrentRow.Cells["uye_id"].Value.ToString() + "'";
            cmd.CommandText = "DELETE FROM kullanici WHERE kul_id = '" + dataGridView2.CurrentRow.Cells["kul_id"].Value.ToString() + "'";
            cmd.ExecuteNonQuery();
            MessageBox.Show("Silme İşlemi Başarılı");
            con.Close();
            musterim();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "UPDATE uyeler SET uye_adi='" + txt_adi.Text + "' , uye_soyadi='" + txt_soyadi.Text + "',uye_mail='" + txt_mail.Text + "',uye_tel='" + txt_telefon.Text + "' where uye_id='" + dataGridView1.CurrentRow.Cells["uye_id"].Value.ToString() + "'";
            cmd.CommandText = "UPDATE kullanici SET k_adi='" + txt_kadi.Text + "' , k_sifre='" + txt_sifre.Text + "',onay='" + txt_onay.Text + "' where kul_id='" + dataGridView2.CurrentRow.Cells["kul_id"].Value.ToString() + "'";

            cmd.ExecuteNonQuery();
            cmd.Dispose();
            MessageBox.Show("Güncelleme İşlemi Başarılı");
            musterim();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

    }
}
