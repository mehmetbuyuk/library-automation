﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace staj_odev
{
    public partial class K_Giris : Form
    {
        public K_Giris()
        {
            InitializeComponent();
            label3.Text = DateTime.Now.ToLongDateString();
            label1.Text = DateTime.Now.ToLongTimeString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            k_listesi kliste = new k_listesi();
            kliste.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            K_okunacak kokunacak = new K_okunacak();
            kokunacak.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            K_okunan kokunan = new K_okunan();
            kokunan.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            K_kiralanan kkiralanan = new K_kiralanan();
            kkiralanan.Show();
        }

        private void K_Giris_Load(object sender, EventArgs e)
        {

        }
    }
}
