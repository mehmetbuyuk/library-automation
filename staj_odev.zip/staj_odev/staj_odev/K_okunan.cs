﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace staj_odev
{
    public partial class K_okunan : Form
    {
        public K_okunan()
        {
            InitializeComponent();
        }

        MySqlConnection con = new MySqlConnection("Server=localhost;Database=kutuphane;user=root;Pwd=;SslMode=none");
        MySqlDataAdapter da;
        MySqlCommand com = new MySqlCommand();
        DataTable table = new DataTable();
        DataTable dt = new DataTable();
        MySqlDataReader dr;
        public void musterim()//Müşterileri Listeleme fonksiyonu
        {


            table.Clear(); // tablomuzu bi temizliyoruz
            MySqlDataAdapter adapter = new MySqlDataAdapter("select kitap_seri, kitap_adi, kitap_turu, yazar_adi, kitap_konusu from okunan ", con);
            adapter.Fill(table);//tablomuza dataadapter ile musterileri dolduruyoruz.//bag.baglan dedik bunun olayı şu
            //bag die bir nesne oluşturduk sqlbaglantisi classımızdan bunun içindeki baglan fonksiyonumuzu çekiyoruz.Biliyorsunuz bağlantı yolumuz burda
            dataGridView1.DataSource = table;//gridwiewe de doldurdumuz tabloya aktardık


            dataGridView1.RowHeadersVisible = false;//satır başlını kaybettik sevmiyorum kaba duruyor

            dataGridView1.Columns[0].Visible = false;//bazı gereksiz kısımları görünmez yaptık görüntü güzelleştirmek açısından "id şifre gibi."
            dataGridView1.MultiSelect = false;//birden fazla satır seçielemez
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect; // seçdiğimiz datagrid satırı tamamen satırca seçilmiş görülür
        }

        private void btn_cikar_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            com.Connection = con;
            com.CommandText = "DELETE FROM okunan WHERE kitap_seri = '" + dataGridView1.CurrentRow.Cells["kitap_seri"].Value.ToString() + "'";
            com.ExecuteNonQuery();
            MessageBox.Show("Silme İşlemi Başarılı");
            musterim();
        }

        private void btn_cikis_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void btn_asayfa_Click(object sender, EventArgs e)
        {
            K_Giris kgiris = new K_Giris();
            kgiris.Show();
            this.Hide();
        }

        private void K_okunan_Load(object sender, EventArgs e)
        {
            con.Open();
            string komut = "select kitap_seri,kitap_adi,kitap_turu,yazar_adi,kitap_konusu from okunan ";
            da = new MySqlDataAdapter(komut, con);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
