﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace staj_odev
{
    public partial class A_Giris : Form
    {
        public A_Giris()
        {
            InitializeComponent();
            label1.Text = DateTime.Now.ToLongDateString();
            label2.Text = DateTime.Now.ToLongTimeString();
        }

        private void btn_kullanici_Click(object sender, EventArgs e)
        {
            Uye_listesi uliste = new Uye_listesi();
            uliste.Show();
        }

        private void btn_kitap_Click(object sender, EventArgs e)
        {
            Kitaplari_yonet kkyonet = new Kitaplari_yonet();
            kkyonet.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void A_Giris_Load(object sender, EventArgs e)
        {

        }
    }
}
