﻿namespace staj_odev
{
    partial class K_okunan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_cikis = new System.Windows.Forms.Button();
            this.btn_cikar = new System.Windows.Forms.Button();
            this.btn_asayfa = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_cikis
            // 
            this.btn_cikis.Location = new System.Drawing.Point(249, 316);
            this.btn_cikis.Margin = new System.Windows.Forms.Padding(2);
            this.btn_cikis.Name = "btn_cikis";
            this.btn_cikis.Size = new System.Drawing.Size(77, 37);
            this.btn_cikis.TabIndex = 7;
            this.btn_cikis.Text = "Çıkış";
            this.btn_cikis.UseVisualStyleBackColor = true;
            this.btn_cikis.Click += new System.EventHandler(this.btn_cikis_Click);
            // 
            // btn_cikar
            // 
            this.btn_cikar.Location = new System.Drawing.Point(163, 316);
            this.btn_cikar.Margin = new System.Windows.Forms.Padding(2);
            this.btn_cikar.Name = "btn_cikar";
            this.btn_cikar.Size = new System.Drawing.Size(77, 37);
            this.btn_cikar.TabIndex = 6;
            this.btn_cikar.Text = "Kitap Çıkar";
            this.btn_cikar.UseVisualStyleBackColor = true;
            this.btn_cikar.Click += new System.EventHandler(this.btn_cikar_Click);
            // 
            // btn_asayfa
            // 
            this.btn_asayfa.Location = new System.Drawing.Point(71, 316);
            this.btn_asayfa.Margin = new System.Windows.Forms.Padding(2);
            this.btn_asayfa.Name = "btn_asayfa";
            this.btn_asayfa.Size = new System.Drawing.Size(77, 37);
            this.btn_asayfa.TabIndex = 5;
            this.btn_asayfa.Text = "Ana Sayfa";
            this.btn_asayfa.UseVisualStyleBackColor = true;
            this.btn_asayfa.Click += new System.EventHandler(this.btn_asayfa_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(8, 8);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(423, 288);
            this.dataGridView1.TabIndex = 4;
            // 
            // K_okunan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 372);
            this.Controls.Add(this.btn_cikis);
            this.Controls.Add(this.btn_cikar);
            this.Controls.Add(this.btn_asayfa);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "K_okunan";
            this.Text = "K_okunan";
            this.Load += new System.EventHandler(this.K_okunan_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_cikis;
        private System.Windows.Forms.Button btn_cikar;
        private System.Windows.Forms.Button btn_asayfa;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}